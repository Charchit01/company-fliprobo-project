#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")


# In[2]:


df = pd.read_excel("customer_retention_dataset.xlsx")


# In[3]:


df.head()


# In[4]:


df.shape


# In[5]:


print("The data set contains: {} rows and {} columns".format(df.shape[0], df.shape[1])) 
print("Number of categorical features : {}".format(len(df.select_dtypes(include=['object']).columns)))
print("Number of numerical features : {}".format(len(df.select_dtypes(include=['int64', 'float64']).columns)))


# In[6]:


df.columns


# In[7]:


df.isnull().sum()


# In[8]:


sns.heatmap(df.isnull())
plt.show()


# In[9]:


df.dtypes


# In[10]:


df.info()


# # DATA ANALYSIS

# In[11]:


for i in df.columns:
    print(i)
    print('num of unique values -->',df[i].nunique())
    if df[i].nunique()<15:
        print(df[i].unique())
    else:
        print(df[i].describe())
        print('*********************************************')
 
    
  


# In[12]:


cat_df,num_df=[],[]
for i in df:
    if df[i].dtypes=='O':
        cat_df.append(i)
    elif (df[i].dtypes=='int') | (df[i].dtypes=='float') | (df[i].dtypes=='int64'):
        num_df.append(i)
    else: print('Unknown >',i)


# In[13]:


print('Total number of features:',df.shape[1])
print('Number of Categorical features:',len(cat_df))
print('Number of Numerical features:',len(num_df))


# In[14]:


for i in cat_df:
    f=plt.figure(figsize=(10,4))
    f.add_subplot(1,1,1)
    sns.countplot(df[i])


# In[15]:


for i in [x for x in df.columns if x not in num_df + ['1Gender of respondent']]:
    plt.figure(figsize=(10,4))
    sns.countplot(x=i,data=df,hue='1Gender of respondent')


# In[16]:


sns.countplot(df['41 Monetary savings'])


# In[17]:


tbl=pd.crosstab(df['25 Convenient Payment methods'],df['Website is as efficient as before'])
(tbl.div(tbl.sum(axis=1),axis=0)*100).plot(kind='bar',stacked=True,figsize=(15,4))
plt.xlabel('PaymentMethod',fontsize=14)
plt.ylabel('Efficiency',fontsize=14)


# In[18]:


tbl=pd.crosstab(df['Change in website/Application design'],df['Frequent disruption when moving from one page to another'])
(tbl.div(tbl.sum(axis=1),axis=0)*100).plot(kind='bar',stacked=True,figsize=(15,4))
plt.xlabel('Web design',fontsize=14)
plt.ylabel('Frequent disruption',fontsize=14)


# In[19]:


tbl=pd.crosstab(df['Security of customer financial information'],df['Perceived Trustworthiness'])
(tbl.div(tbl.sum(axis=1),axis=0)*100).plot(kind='bar',stacked=True,figsize=(15,4))
plt.xlabel('Security of financial info',fontsize=14)
plt.ylabel('% of trust',fontsize=14)


# In[20]:


tbl=pd.crosstab(df['1Gender of respondent'],df['Which of the Indian online retailer would you recommend to a friend?'])
(tbl.div(tbl.sum(axis=1),axis=0)*100).plot(kind='bar',stacked=True,figsize=(15,4))
plt.xlabel('Gender of the customer',fontsize=14)
plt.ylabel('Indian online retailer would you recommend to a friend',fontsize=14)


# In[ ]:




